# VYBORA

Cross-platform social video platform foundation.

## Monorepo
- `apps/mobile`: Expo + React Native app (Android, iOS, web)
- `apps/admin`: Next.js private administration portal
- `supabase/migrations`: PostgreSQL schema and row-level security policies
- `docs/PRODUCTION_CHECKLIST.md`: services, secrets, deployment and launch gates

## Important status
This is a source-code foundation, not a deployed production service. Real authentication, uploads, live rooms, payments, push notifications and admin operations require provisioning the external services, adding environment secrets, running migrations, testing, and deploying. Never commit production secrets.

## Start
See the app-specific README files. Copy each `.env.example` to `.env` and supply your own project credentials before connecting services.
