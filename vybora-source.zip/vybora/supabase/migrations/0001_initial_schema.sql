-- VYBORA initial relational model. Apply via Supabase migrations after reviewing policies.
create extension if not exists pgcrypto;
create type public.account_status as enum ('active','suspended','deleted');
create type public.video_visibility as enum ('public','followers','private');
create type public.report_status as enum ('open','reviewing','resolved','dismissed');
create table public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 username text unique not null check (char_length(username) between 3 and 30),
 display_name text not null default '', bio text not null default '', avatar_url text,
 status public.account_status not null default 'active', is_verified boolean not null default false,
 created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.user_roles (
 user_id uuid not null references auth.users(id) on delete cascade,
 role text not null check (role in ('user','moderator','admin','owner')),
 created_at timestamptz not null default now(), primary key(user_id,role)
);
create table public.videos (
 id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id),
 caption text not null default '', video_path text not null, thumbnail_path text,
 duration_seconds integer check (duration_seconds between 1 and 600), visibility public.video_visibility not null default 'public',
 moderation_state text not null default 'pending' check (moderation_state in ('pending','approved','rejected','removed')),
 view_count bigint not null default 0, created_at timestamptz not null default now()
);
create table public.follows (follower_id uuid references public.profiles(id) on delete cascade, followed_id uuid references public.profiles(id) on delete cascade, created_at timestamptz not null default now(), primary key(follower_id,followed_id), check(follower_id <> followed_id));
create table public.video_likes (user_id uuid references public.profiles(id) on delete cascade, video_id uuid references public.videos(id) on delete cascade, created_at timestamptz not null default now(), primary key(user_id,video_id));
create table public.comments (id uuid primary key default gen_random_uuid(), video_id uuid not null references public.videos(id) on delete cascade, user_id uuid not null references public.profiles(id), body text not null check(char_length(body) between 1 and 2000), created_at timestamptz not null default now());
create table public.reports (id uuid primary key default gen_random_uuid(), reporter_id uuid not null references public.profiles(id), target_type text not null check(target_type in ('user','video','comment','live_room')), target_id uuid not null, reason text not null, details text not null default '', status public.report_status not null default 'open', reviewed_by uuid references public.profiles(id), reviewed_at timestamptz, created_at timestamptz not null default now());
create table public.live_rooms (id uuid primary key default gen_random_uuid(), host_id uuid not null references public.profiles(id), title text not null, livekit_room_name text unique not null, status text not null default 'scheduled' check(status in ('scheduled','live','ended','blocked')), started_at timestamptz, ended_at timestamptz, created_at timestamptz not null default now());
create table public.wallet_ledger (id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id), entry_type text not null check(entry_type in ('credit','debit','hold','release','refund')), amount_minor bigint not null check(amount_minor > 0), currency char(3) not null, reference text unique not null, status text not null check(status in ('pending','posted','failed','reversed')), created_at timestamptz not null default now());
create table public.notifications (id uuid primary key default gen_random_uuid(), user_id uuid not null references public.profiles(id) on delete cascade, kind text not null, payload jsonb not null default '{}', read_at timestamptz, created_at timestamptz not null default now());
create index videos_feed_idx on public.videos(moderation_state,visibility,created_at desc);
create index comments_video_idx on public.comments(video_id,created_at desc);
create index notifications_user_idx on public.notifications(user_id,created_at desc);

alter table public.profiles enable row level security;
alter table public.user_roles enable row level security;
alter table public.videos enable row level security;
alter table public.follows enable row level security;
alter table public.video_likes enable row level security;
alter table public.comments enable row level security;
alter table public.reports enable row level security;
alter table public.live_rooms enable row level security;
alter table public.wallet_ledger enable row level security;
alter table public.notifications enable row level security;

create or replace function public.has_staff_role() returns boolean language sql stable security definer set search_path=public as $$ select exists(select 1 from public.user_roles where user_id=auth.uid() and role in ('moderator','admin','owner')) $$;
create policy "profiles visible" on public.profiles for select using (status='active' or id=auth.uid() or public.has_staff_role());
create policy "profile owner update" on public.profiles for update using (id=auth.uid()) with check (id=auth.uid());
create policy "profile owner insert" on public.profiles for insert with check (id=auth.uid());
create policy "roles private" on public.user_roles for select using (user_id=auth.uid() or public.has_staff_role());
create policy "approved public videos" on public.videos for select using ((moderation_state='approved' and visibility='public') or user_id=auth.uid() or public.has_staff_role());
create policy "owner create video" on public.videos for insert with check (user_id=auth.uid());
create policy "owner update video" on public.videos for update using (user_id=auth.uid() or public.has_staff_role()) with check (user_id=auth.uid() or public.has_staff_role());
create policy "follow graph readable" on public.follows for select using (true);
create policy "follow self" on public.follows for insert with check (follower_id=auth.uid());
create policy "unfollow self" on public.follows for delete using (follower_id=auth.uid());
create policy "likes readable" on public.video_likes for select using (true);
create policy "like self" on public.video_likes for insert with check (user_id=auth.uid());
create policy "unlike self" on public.video_likes for delete using (user_id=auth.uid());
create policy "comments readable on approved video" on public.comments for select using (exists(select 1 from public.videos v where v.id=video_id and v.moderation_state='approved' and v.visibility='public') or user_id=auth.uid() or public.has_staff_role());
create policy "comment as self" on public.comments for insert with check (user_id=auth.uid());
create policy "comment owner or staff delete" on public.comments for delete using (user_id=auth.uid() or public.has_staff_role());
create policy "reporter create report" on public.reports for insert with check (reporter_id=auth.uid());
create policy "reporter or staff read report" on public.reports for select using (reporter_id=auth.uid() or public.has_staff_role());
create policy "live rooms visible" on public.live_rooms for select using (status='live' or host_id=auth.uid() or public.has_staff_role());
create policy "host creates live room" on public.live_rooms for insert with check (host_id=auth.uid());
create policy "wallet private" on public.wallet_ledger for select using (user_id=auth.uid() or public.has_staff_role());
create policy "notifications private" on public.notifications for select using (user_id=auth.uid());
create policy "notification read self" on public.notifications for update using (user_id=auth.uid()) with check (user_id=auth.uid());

-- Deliberately no client-side wallet mutation policy: ledger writes must be performed by trusted server functions.
-- Admin role assignment must also be performed only by a trusted owner-only server function.
