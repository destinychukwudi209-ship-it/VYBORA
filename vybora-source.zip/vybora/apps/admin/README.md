# VYBORA admin portal
Next.js private admin UI foundation. It intentionally shows unconnected metrics as unavailable rather than inventing live counts. Before deployment, implement server-side authentication, MFA, authorization on every route/action and audit logging. Never expose the Supabase service-role key to browser code.
