export const theme = {
  bg: '#050509', panel: '#11111B', panel2: '#1A1A29', purple: '#7C22F5', violet: '#B12BFF', blue: '#245DDE', text: '#FFFFFF', muted: '#A5A5B5', line: '#29293A', pink: '#FF3F87'
};
