# VYBORA mobile/web client
Expo Router app targeting Android, iOS and web. The current source establishes the dark purple navigation and screen structure. Camera/gallery permissions, upload pipeline, authenticated sessions, live-room tokens, realtime messaging and wallet actions are integration tasks documented in `../../docs/PRODUCTION_CHECKLIST.md`.
