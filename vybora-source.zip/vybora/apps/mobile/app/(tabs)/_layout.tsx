import { Tabs } from 'expo-router';
import { Ionicons } from '@expo/vector-icons';
import { theme as t } from '../../src/theme';
const icons:any={index:'home',discover:'compass',create:'add-circle',inbox:'chatbubble-ellipses',profile:'person'};
export default function TabLayout(){return <Tabs screenOptions={({route})=>({headerShown:false,tabBarStyle:{backgroundColor:'#090910',borderTopColor:t.line,height:68,paddingBottom:9,paddingTop:7},tabBarActiveTintColor:t.violet,tabBarInactiveTintColor:'#8B8B9B',tabBarLabelStyle:{fontSize:10,fontWeight:'700'},tabBarIcon:({color,size})=><Ionicons name={icons[route.name]||'ellipse'} size={size+2} color={color}/>})}><Tabs.Screen name="index" options={{title:'Home'}}/><Tabs.Screen name="discover" options={{title:'Discover'}}/><Tabs.Screen name="create" options={{title:'Create'}}/><Tabs.Screen name="inbox" options={{title:'Inbox'}}/><Tabs.Screen name="profile" options={{title:'Profile'}}/></Tabs>;}
