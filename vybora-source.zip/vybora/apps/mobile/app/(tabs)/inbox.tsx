import { View,Text } from 'react-native'; import { theme as t } from '../../src/theme';
export default function Inbox(){return <View style={{flex:1,backgroundColor:t.bg,padding:22,paddingTop:60}}><Text style={{color:'white',fontSize:28,fontWeight:'900'}}>Messages</Text><Text style={{color:t.muted,marginTop:18}}>Your conversations will appear here when messaging is connected.</Text></View>}
