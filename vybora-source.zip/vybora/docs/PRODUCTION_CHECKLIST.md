# Production launch gates

## Accounts and secrets required
- Supabase project: URL, anon key, server-only service-role key; configure Auth providers, email templates, database backups and storage.
- LiveKit Cloud: WebSocket URL and server API key/secret. Mint short-lived room tokens only from a trusted server/Edge Function after authorization checks.
- Payments: Paystack business account and verified webhook secret. Never trust client payment callbacks; verify webhook signatures and reconcile transactions server-side. Keep amounts in minor currency units and maintain an append-only ledger.
- Push: APNs and FCM credentials; configure Expo/EAS or native builds.
- Domains, DNS, TLS, app store developer accounts, privacy policy, terms, community guidelines and support contact.

## Required implementation before public launch
- Real sign-up/login, email/phone verification, password reset, account deletion and session revocation.
- Storage buckets with upload limits, signed playback URLs where required, transcoding, thumbnails, content scanning and CDN delivery.
- Feed ranking/pagination, view-event deduplication, rate limits, abuse prevention and moderation queues.
- Messaging authorization, realtime delivery, blocking, reporting and retention controls.
- Live room lifecycle, host/co-host permissions, viewer limits, moderation, reconnect handling and recording policy.
- Server-only gifts, purchases, refunds, withdrawal review, KYC/AML checks where applicable, payout reconciliation and fraud controls.
- Admin authentication with MFA, server-side role checks on every operation, least privilege and immutable audit events.
- Observability, error tracking, backups, restore drills, load tests, security review and incident response.
- Legal review for Nigerian data protection, child safety, copyright, financial/payment rules and platform policies in every launch market.

## Deployment
- Mobile: EAS Build/Submit for Android and iOS; configure app identifiers, signing, privacy declarations and store listings.
- Web: deploy the Expo web client and Next.js admin separately; protect admin routes on the server.
- Backend: apply migrations to staging first, seed only test data, run RLS/security tests, then promote to production.

Do not launch with placeholder metrics, fake balances, sample creators, nonfunctional buttons or test credentials.
